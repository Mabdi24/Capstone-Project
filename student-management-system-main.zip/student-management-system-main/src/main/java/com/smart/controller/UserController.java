package com.smart.controller;

import java.security.Principal;

import com.smart.dao.CourseRepository;
import com.smart.dao.InstructorRepository;
import com.smart.dao.StudentRepository;
import com.smart.entities.Course;
import com.smart.entities.Instructor;
import com.smart.entities.Student;
import com.smart.helper.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.smart.dao.UserRepository;
import com.smart.entities.User;

import javax.servlet.http.HttpSession;

/**
 * User Controller controls all urls after logging in
 */
@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private InstructorRepository instructorRepository;
	@Autowired
	private CourseRepository courseRepository;
	@Autowired
	private StudentRepository studentRepository;
	// method for adding common data to response

	/**
	 * To add the common data means sending user that is currently logged in
	 * @param model
	 * @param principal
	 */
	@ModelAttribute
	public void addCommonData(Model model, Principal principal) {
		String userName = principal.getName();
		System.out.println("USERNAME " + userName);

		// get the user using usernamne(Email)

		User user = userRepository.getUserByUserName(userName);
		System.out.println("USER " + user);
		model.addAttribute("user", user);

	}

	/**
	 * used for viewing profile
	 * @param model
	 * @return
	 */
	@GetMapping("/profile")
	public String yourProfile(Model model) {
		model.addAttribute("title", "Profile Page");
		return "normal/profile";
	}

	/**
	 * directs to index page
	 * @param model
	 * dashboard home
	 * @param principal
	 * @return
	 */
	@RequestMapping("/index")
	public String dashboard(Model model, Principal principal) {
		model.addAttribute("title", "User Dashboard");
		return "normal/user_dashboard";
	}

	/**
	 * open add instructor form handler
	 * used for adding instructor
	 * @param model
	 * @return
	 */
	@GetMapping("/add-instructor")
	public String openAddContactForm(Model model) {
		model.addAttribute("title", "Add Instructor");
		model.addAttribute("contact", new Instructor());

		return "normal/add_instructor_form";
	}

	/**
	 * this url processes the data from instructor page and verifies and then saves to db
	 * rocessing add contact form
	 * @param instructor
	 * @param session
	 * @return
	 */
	@PostMapping("/process-instructor")
	public String processContact(@ModelAttribute("instructor") Instructor instructor, HttpSession session) {
		try {
			Course course= courseRepository.findByCourseId(instructor.getCourseId());
			instructor.setCourse(course.getName());
			Instructor instructor1= instructorRepository.save(instructor);
			System.out.println("DATA " + instructor1);
			System.out.println("Added to data base");
			// message success.......
			session.setAttribute("message", new Message("Your instructor is added !! Add more..", "success"));
		} catch (Exception e) {
			System.out.println("ERROR " + e.getMessage());
			e.printStackTrace();
			// message error
			session.setAttribute("message", new Message("Some went wrong !! Try again..", "danger"));

		}

		return "normal/