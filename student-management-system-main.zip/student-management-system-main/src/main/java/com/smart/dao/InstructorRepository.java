package com.smart.dao;

import com.smart.entities.Instructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * this is instructor repository, in this we write the server queries to obtain data from server
 */
public interface InstructorRepository extends JpaRepository<Instructor, Integer> {
	/**
	 * find instructor with email
	 
	 */
	@Query("select ins from Instructor ins where ins.email = :email")
	public Instructor getInstructorByUserName(@Param("email") String email);


	@Query("select instructor from Instructor instructor ")
	public Page<Instructor> findContactsByUser(Pageable pePageable);

}
